export const environment = {
  ROOT_API : 'http://localhost:8080/back/api/',
  production: true
};
