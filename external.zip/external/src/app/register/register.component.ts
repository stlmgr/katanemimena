import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { AuthService } from '../_services/auth.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  form: any = {};
  isSuccessful = false;
  isSignUpFailed = false;
  errorMessage = '';

  rolesArray = [
    'phd',
    'secretery',
    'supervisor',
    'general assembly'
] 

  constructor(private authService: AuthService) { }

  ngOnInit(): void {
  }

  onSubmit(): void {

    var user = new User();
    user.name = this.form.name;
    user.surname = this.form.surname;
    user.email = this.form.email;
    user.username = this.form.username;
    user.password = this.form.password;
    user.roles.push(this.form.roles);
    this.authService.register(user).subscribe(
      data => {
        this.isSuccessful = true;
        this.isSignUpFailed = false;
      },
      err => {
        console.log(err)
        this.errorMessage = err.error.message;
        this.isSignUpFailed = true;
      }
    );
  }

}
