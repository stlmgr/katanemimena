export class User {
    id: string;
    username: string;
    name: string;
    surname: string;
    email: string;
    password: string;
    activate: boolean;
    roles: string[]=[];
}