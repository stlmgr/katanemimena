import { User } from "./user";


export class PhDWork {
    id: string;
    teachingLaboratories: string;
    surveillance: string;
    writingCorrections: number;
    semester: string;
    done: Boolean;
    userDTO: User[]=[];
}