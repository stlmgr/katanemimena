import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { PhdBoardComponent } from './phd/phd-board/phd-board.component';
import { ProfileUpdateComponent } from './profile-update/profile-update.component';
import { SecreteryBoardComponent } from './secretery/secretery-board/secretery-board.component';
import { SecreteryAddComponent } from './secretery/secretery-add/secretery-add.component';
import { TeacherSetWorkComponent } from './teacher/teacher-set-work/teacher-set-work.component';
import { SecreteryWorkTimeComponent } from './secretery/secretery-work-time/secretery-work-time.component';
import { TeacherBoardComponent } from './teacher/teacher-board/teacher-board.component';
import { TeacherWorkFormComponent } from './teacher/teacher-work-form/teacher-work-form.component';


const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'phd', component: PhdBoardComponent },
  { path: 'update/:id', component: ProfileUpdateComponent },
  { path: 'secretery', component: SecreteryBoardComponent },
  { path: 'secretery/add', component: SecreteryAddComponent },
  { path: 'add/:id', component: SecreteryWorkTimeComponent },
  { path: 'teacher', component: TeacherBoardComponent },
  { path: 'teacher/table/:id', component: TeacherSetWorkComponent },
  { path: 'teacher/add/:id', component: TeacherWorkFormComponent },


  { path: '', redirectTo: 'test', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
