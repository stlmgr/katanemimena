import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { authInterceptorProviders } from './_helpers/auth.interceptor';
import { PhdBoardComponent } from './phd/phd-board/phd-board.component';
import { ProfileUpdateComponent } from './profile-update/profile-update.component';
import { SecreteryBoardComponent } from './secretery/secretery-board/secretery-board.component';
import { SecreteryAddComponent } from './secretery/secretery-add/secretery-add.component';

import { DatePipe } from '@angular/common';
import { TeacherSetWorkComponent } from './teacher/teacher-set-work/teacher-set-work.component';
import { SecreteryWorkTimeComponent } from './secretery/secretery-work-time/secretery-work-time.component';
import { TeacherBoardComponent } from './teacher/teacher-board/teacher-board.component';
import { TeacherWorkFormComponent } from './teacher/teacher-work-form/teacher-work-form.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    ProfileComponent,
    PhdBoardComponent,
    ProfileUpdateComponent,
    SecreteryBoardComponent,
    SecreteryAddComponent,
    TeacherSetWorkComponent,
    SecreteryWorkTimeComponent,
    TeacherBoardComponent,
    TeacherWorkFormComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
  ],
  providers: [
    authInterceptorProviders,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
