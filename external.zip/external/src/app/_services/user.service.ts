import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs";
import { environment } from "src/environments/environment";


const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" }),
};

@Injectable({
  providedIn: "root",
})
export class UserService {
  constructor(private http: HttpClient) {}

  getUserById(id: number): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/phd/get/user/${id}`);
  }

  updateUser(id: number, value: any): Observable<Object> {
    return this.http.put(`${environment.ROOT_API}/phd/update/${id}`, value);
  }

  getUserWork(id: number): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/phd/get/work/${id}`);
  }

  getUsers(): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/secretery/get`);
  }

  deleteUser(id: number): Observable<any> {
    return this.http.delete(`${environment.ROOT_API}/secretery/delete/user/${id}`, {
      responseType: "text",
    });
  }

  activateUser(id:string, acti: Boolean): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/secretery/activate/${acti}/${id}`);
  }

  addWork(id:string, work): Observable<any> {
    return this.http.post(`${environment.ROOT_API}/secretery/store/${id}`,
      {
        teachingLaboratories: work.teachingLaboratories,
        surveillance: work.surveillance,
        writingCorrections: work.writingCorrections,
        semester: work.semester,
      },
      httpOptions
    );
  }

  workDoneSecretery(id:string, acti: Boolean): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/secretery/done/${acti}/${id}`);
  }

  workDonePhD(id:string, acti: Boolean): Observable<any> {
    return this.http.get(`${environment.ROOT_API}/phd/done/${acti}/${id}`);
  }

 
}
