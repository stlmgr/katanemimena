import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PhDWork } from 'src/app/models/phdwork';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/_services/user.service';



@Component({
  selector: 'app-secretery-board',
  templateUrl: './secretery-board.component.html',
  styleUrls: ['./secretery-board.component.css']
})
export class SecreteryBoardComponent implements OnInit {

  user: Observable<User[]>;

  constructor(private userService: UserService,
    private router: Router) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.userService.getUsers().subscribe(
      data => {
        console.log(data);
        this.user = data;
      },
      error => console.log(error));
  }

  deleteUser(id: number) {
    this.userService.deleteUser(id)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

  activate(id: string, bool:Boolean){
    this.userService.activateUser(id,bool)
      .subscribe(
        data => {
          this.reloadData();
        },
        error => console.log(error));
  }

  updateUser(id: number){
    this.router.navigate(['update', id]);
  }

  addWorkUser(id: number){
    this.router.navigate(['add', id]);
  }

  addUser(){
    this.router.navigate(['secretery/add']);
  }
}
