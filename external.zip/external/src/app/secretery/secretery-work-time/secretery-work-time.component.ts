import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PhDWork } from 'src/app/models/phdwork';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-secretery-work-time',
  templateUrl: './secretery-work-time.component.html',
  styleUrls: ['./secretery-work-time.component.css']
})
export class SecreteryWorkTimeComponent implements OnInit {

  id: number;
  works: Observable<PhDWork[]>;
  constructor( private route: ActivatedRoute,
    private userService: UserService) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
    this.reload();
  }

  end(id,bool){
    console.log(id)
    this.userService.workDoneSecretery(id,bool).subscribe(
      data => {
      alert(data.message);
      this.reload();
      },
      err => {
        console.log(err);
      }
    );
  }

  reload(){
    this.userService.getUserWork(this.id).subscribe(
      data => {
        console.log(data);
      this.works = data;
      },
      err => {
        console.log(err);
      }
    );
  }


}
