import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PhDWork } from 'src/app/models/phdwork';
import { TokenStorageService } from 'src/app/_services/token-storage.service';
import { UserService } from 'src/app/_services/user.service';



@Component({
  selector: 'app-phd-board',
  templateUrl: './phd-board.component.html',
  styleUrls: ['./phd-board.component.css']
})
export class PhdBoardComponent implements OnInit {

  work: Observable<PhDWork[]>;

  currentUser;
  constructor(private userService: UserService,
    private token: TokenStorageService,
    private router: Router) {}

  ngOnInit() {
    this.currentUser = this.token.getUser();
    this.reload();
  }

  end(id,bool){
    console.log(id)
    this.userService.workDonePhD(id,bool).subscribe(
      data => {
      alert(data.message);
      this.reload();
      },
      err => {
        console.log(err);
      }
    );
  }

  reload(){
    this.userService.getUserWork(this.currentUser.id).subscribe(
      data => {
      this.work = data;
      },
      err => {
        console.log(err);
      }
    );
  }

}
