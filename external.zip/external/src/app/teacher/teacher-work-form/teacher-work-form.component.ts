import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/_services/auth.service';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-teacher-work-form',
  templateUrl: './teacher-work-form.component.html',
  styleUrls: ['./teacher-work-form.component.css']
})
export class TeacherWorkFormComponent implements OnInit {

  semesterArray = [
    '1 εξάμηνο',
    '2 εξάμηνο'
] 
isSuccessful = false;
isSignUpFailed = false;
id;


  form: any = {};

  constructor( private userService: UserService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    this.id = this.route.snapshot.params['id'];
  }

  reload(){
    this.router.navigate(['teacher/table', this.id]);
  }

  onSubmit(): void {

    if(this.form.teachingLaboratories + this.form.surveillance + this.form.writingCorrections/5 == 80){
    this.userService.addWork(this.id,this.form).subscribe(
      data => {
        console.log(data);
      this.isSuccessful = true;
      this.isSignUpFailed = false;
      setTimeout(()=>{
        this.reload();
      }, 2000);
      },
      err => {
        console.log(err)
      }
    );
    }else{
      this.isSuccessful = false;
      this.isSignUpFailed = true;
    }
  }


}
