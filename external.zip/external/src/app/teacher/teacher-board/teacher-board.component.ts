import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user';
import { UserService } from 'src/app/_services/user.service';

@Component({
  selector: 'app-teacher-board',
  templateUrl: './teacher-board.component.html',
  styleUrls: ['./teacher-board.component.css']
})
export class TeacherBoardComponent implements OnInit {

  user: Observable<User[]>;
  
  constructor(private userService: UserService,
    private router: Router) { }

  ngOnInit(): void {
    this.userService.getUsers().subscribe(
      data => {
        console.log(data);
        this.user = data;
      },
      error => console.log(error));
  }

  addWorkUser(id: number){
    this.router.navigate(['teacher/table', id]);
  }

}
